import java.io.*;
import java.util.*;
public class Spaceship {
    
    public static void main(String[] args) {
        
        try{
            File input = new File(args[0]);
            Scanner sc = new Scanner(input);
            List<Double> inp = new ArrayList<Double>();
            double p;
            while(sc.hasNextDouble()){
                p = sc.nextDouble();
                inp.add(p);
            }
            System.out.println(inp);
        }
        catch(FileNotFoundException exc){
            System.out.println("File not found!!");
        }
    }
}