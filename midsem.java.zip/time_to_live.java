import java.util.*;

private class Double time_to_live(ArrayList<Double> inp)
{
        
	Double[] nums = new Double[inp.size() + 2];
	int n = 1;

	for (Double x : inp)
	{
		if (x > 0)
		{
	          nums[n++] = x;
		}
	}
	nums[0] = nums[n++] = 0;


	Double[][] dp = new Double[n][n];
	for (int k = 2; k < n; ++k)
	{
		for (int left = 0; left < n - k; ++left)
		{
			int right = left + k;
			for (int i = left + 1; i < right; ++i)
			{
			dp[left][right] = max(dp[left][right], nums[left] / 2.0 + nums[i] + nums[right] / 2 + dp[left][i] + dp[i][right]);
			}
		}
	}

	return dp[0][n - 1];
}

private static int Main()
{
  
  freopen("Spaceships.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
  int number_spaceships;
  number_spaceships = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
  ArrayList<Double> inp = new ArrayList<Double>();
  for (int i = 1; i <= number_spaceships; i++)
  {
	  Double d;
	  d = Double.parseDouble(ConsoleInput.readToWhiteSpace(true));
	inp.add(d);
  }

  System.out.printf("%.10f", time_to_live(inp));

  return 0;
}


public final class ConsoleInput
{
	private static boolean goodLastRead = false;
	public static boolean lastReadWasGood()
	{
		return goodLastRead;
	}

	public static String readToWhiteSpace(boolean skipLeadingWhiteSpace)
	{
		String input = "";
		char nextChar;
		while (Character.isWhitespace(nextChar = (char)System.in.read()))
		{
			//accumulate leading white space if skipLeadingWhiteSpace is false:
			if (!skipLeadingWhiteSpace)
			{
				input += nextChar;
			}
		}
		//the first non white space character:
		input += nextChar;

		//accumulate characters until white space is reached:
		while (!Character.isWhitespace(nextChar = (char)System.in.read()))
		{
			input += nextChar;
		}

		goodLastRead = input.length() > 0;
		return input;
	}

	public static String scanfRead()
	{
		return scanfRead(null, -1);
	}

	public static String scanfRead(String unwantedSequence)
	{
		return scanfRead(unwantedSequence, -1);
	}

	public static String scanfRead(String unwantedSequence, int maxFieldLength)
	{
		String input = "";

		char nextChar;
		if (unwantedSequence != null)
		{
			nextChar = '\0';
			for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
			{
				if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
				{
					//ignore all subsequent white space:
					while (Character.isWhitespace(nextChar = (char)System.in.read()))
					{
					}
				}
				else
				{
					//ensure each character matches the expected character in the sequence:
					nextChar = (char)System.in.read();
					if (nextChar != unwantedSequence.charAt(charIndex))
						return null;
				}
			}

			input = (new Character(nextChar)).toString();
			if (maxFieldLength == 1)
				return input;
		}

		while (!Character.isWhitespace(nextChar = (char)System.in.read()))
		{
			input += nextChar;
			if (maxFieldLength == input.length())
				return input;
		}

		return input;
	}
}
}